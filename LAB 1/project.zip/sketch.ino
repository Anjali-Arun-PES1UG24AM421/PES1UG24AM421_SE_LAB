#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/i2c.h"
#include "esp_err.h"

#define I2C_MASTER_SDA_IO 18
#define I2C_MASTER_SCL_IO 19
#define I2C_MASTER_NUM I2C_NUM_0
#define I2C_MASTER_FREQ_HZ 100000
#define MPU6050_ADDR 0x68
#define MPU6050_PWR_MGMT_1 0x6B
#define MPU6050_ACCEL_XOUT_H 0x3B
#define MPU6050_TEMP_OUT_H 0x41
#define MPU6050_GYRO_XOUT_H 0x43

// Write one byte to MPU6050 register

static esp_err_t mpu6050_write_byte(uint8_t reg, uint8_t data)
{
    uint8_t buffer[2] = {reg, data};
    return i2c_master_write_to_device(
        I2C_MASTER_NUM, MPU6050_ADDR, buffer, 2, pdMS_TO_TICKS(100));
}

// Read multiple bytes from MPU6050

static esp_err_t mpu6050_read_bytes(uint8_t reg, uint8_t *data, size_t length)
{
    return i2c_master_write_read_device(
        I2C_MASTER_NUM, MPU6050_ADDR, &reg, 1, data, length, pdMS_TO_TICKS(100));
}

// Read signed 16-bit value

static int16_t combine_bytes(uint8_t high, uint8_t low)
{
    return (int16_t)((high << 8) | low);
}

void app_main(void)
{
    printf("Hello, Wokwi!\n");
    // ---------------------------------
    // I2C configuration
    // ---------------------------------
    i2c_config_t conf = {};
    conf.mode = I2C_MODE_MASTER;
    conf.sda_io_num = I2C_MASTER_SDA_IO;
    conf.scl_io_num = I2C_MASTER_SCL_IO;
    conf.sda_pullup_en = GPIO_PULLUP_ENABLE;
    conf.scl_pullup_en = GPIO_PULLUP_ENABLE;
    conf.master.clk_speed = I2C_MASTER_FREQ_HZ;
    conf.clk_flags = 0;
    ESP_ERROR_CHECK(i2c_param_config(I2C_MASTER_NUM, &conf));
    ESP_ERROR_CHECK(i2c_driver_install(I2C_MASTER_NUM, conf.mode, 0, 0, 0));
    printf("I2C initialized: SDA=%d, SCL=%d\n", I2C_MASTER_SDA_IO, I2C_MASTER_SCL_IO);
    // ---------------------------------
    // Wake up MPU6050
    // ---------------------------------
    ESP_ERROR_CHECK(mpu6050_write_byte(MPU6050_PWR_MGMT_1, 0x00));
    printf("MPU6050 initialized!\n");
    // ---------------------------------
    // Read MPU6050 continuously
    // --------------------------------
    uint8_t data[14];
    while (1)
    {
        esp_err_t ret = mpu6050_read_bytes(MPU6050_ACCEL_XOUT_H, data, 14);
        if (ret == ESP_OK)
        {
            int16_t accel_x = combine_bytes(data[0], data[1]);
            int16_t accel_y = combine_bytes(data[2], data[3]);
            int16_t accel_z = combine_bytes(data[4], data[5]);
            int16_t temperature_raw = combine_bytes(data[6], data[7]);
            int16_t gyro_x = combine_bytes(data[8], data[9]);
            int16_t gyro_y = combine_bytes(data[10], data[11]);
            int16_t gyro_z = combine_bytes(data[12], data[13]);
            float accel_x_g = accel_x / 16384.0f;
            float accel_y_g = accel_y / 16384.0f;
            float accel_z_g = accel_z / 16384.0f;
            float gyro_x_dps = gyro_x / 131.0f;
            float gyro_y_dps = gyro_y / 131.0f;
            float gyro_z_dps = gyro_z / 131.0f;
            float temperature = (temperature_raw / 340.0f) + 36.53f;
            printf("\n");
            printf("========== MPU6050 ==========\n");
            printf("ACCEL X: %.2f g | Y: %.2f g | Z: %.2f g\n", accel_x_g, accel_y_g, accel_z_g);
            printf("GYRO X: %.2f dps | Y: %.2f dps | Z: %.2f dps\n", gyro_x_dps, gyro_y_dps, gyro_z_dps);
            printf("TEMP : %.2f C\n", temperature);
            printf("==============================\n");
        }
        else
        {
            printf("MPU6050 read failed: %s\n", esp_err_to_name(ret));
        }
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}
// Arduino entry wrappers to satisfy the linker
void setup() {
    app_main();
}
void loop() {
}